# Execution record

## Lean

**NOT RUN.** No `lean` or `lake` executable was available in the authoring
container. Attempts to retrieve a Lean distribution were unsuccessful.
No compilation-success log, kernel acceptance, or axiom-audit output is claimed.
All Lean files are source drafts.

## Python

The following commands were executed successfully:

```text
python reference/three_squares_circle_certificate.py
python scripts/generate_data.py
```

The reference verifier reported 48 branches, 53 certificates, and 160 vertex
checks. The generator successfully wrote all 53 Lean data records and verified
that its coarser rational endpoint intervals retain the required strict gap.
These executions do not validate Lean syntax, prove the analytic soundness of
Lean's interval data, or complete the geometric reductions.

## Mathematical scope

The unrestricted `OptimalityStatement` remains unproved in this project.
`optimality_of_certificate_existence` is conditional on the explicitly unproved
`MissingCertificateExistence` proposition.
