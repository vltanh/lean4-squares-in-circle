import ThreeSquares

-- These commands report dependencies when Lean is actually run.
-- No output from them is claimed in this distribution.
#print axioms ThreeSquares.tSquares_packing
#print axioms ThreeSquares.tSquares_radius_lower
#print axioms ThreeSquares.three_square_dual
#print axioms ThreeSquares.Combinatorics.classification
#print axioms ThreeSquares.AngleDomain.cover_G
#print axioms ThreeSquares.AngleDomain.cover_H
#print axioms ThreeSquares.AngleDomain.cover_J_special
#print axioms ThreeSquares.RatData.all_checked
#print axioms ThreeSquares.optimality_of_certificate_existence

-- Inspect the hypothesis of the last theorem; it is essential and unproved.
#check ThreeSquares.MissingCertificateExistence
#check ThreeSquares.optimality_of_certificate_existence
