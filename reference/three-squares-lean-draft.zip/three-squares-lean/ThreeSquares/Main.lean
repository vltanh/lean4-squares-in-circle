import ThreeSquares.Construction
import ThreeSquares.Dual
import ThreeSquares.Arithmetic
import ThreeSquares.Combinatorics
import ThreeSquares.AngleDomain
import ThreeSquares.Certificates

/-!
# The precise remaining obligation

This file DOES NOT prove `OptimalityStatement` unconditionally.
`MissingCertificateExistence` names the unresolved geometric/analytic bridge.
It is a proposition, NOT an axiom or a theorem, and no inhabitant is supplied.
The conditional theorem below must not be described as a proof of the original
packing problem.

Status: source draft, not compiled in the authoring environment.
-/
noncomputable section
open scoped BigOperators
namespace ThreeSquares

/-- Data sufficient for the algebraic lower bound, without asserting it exists. -/
structure CertificateWitness (S : Fin 3 → UnitSquare) (o : Point) where
  normals : Fin 3 → Point
  lam : Fin 3 → Fin 4 → ℝ
  mu : Fin 3 → ℝ
  widths : Fin 3 → ℝ
  lam_nonneg : ∀ i j, 0 ≤ lam i j
  lam_sum : (∑ i, ∑ j, lam i j) = 1
  mass_pos : ∀ i, 0 < mass (lam i)
  mu_nonneg : ∀ e, 0 ≤ mu e
  separation : ∀ e, widths e ≤ dot (normals e)
    (sub (sub (S (edgeEnd e)).center o) (sub (S (edgeStart e)).center o))
  value_lower : targetSq ≤
    dualValue (fun i j => rotate (S i) (localVertex j)) lam mu widths normals

/-- UNPROVED obligation. The finite rational checks alone do not establish this. -/
def MissingCertificateExistence : Prop :=
  ∀ (S : Fin 3 → UnitSquare) (o : Point) (R : ℝ),
    Packing S o R → R ^ 2 < targetSq → Nonempty (CertificateWitness S o)

/-- Conditional only: it requires a proof of the explicitly missing obligation. -/
theorem optimality_of_certificate_existence
    (hcert : MissingCertificateExistence) : OptimalityStatement := by
  intro S o R hp
  by_cases hbig : targetSq ≤ R ^ 2
  · exact radius_lower_of_squared hp.1 hbig
  · obtain ⟨w⟩ := hcert S o R hp (lt_of_not_ge hbig)
    exact radius_lower_from_certificate hp w.normals w.lam w.mu w.widths
      w.lam_nonneg w.lam_sum w.mass_pos w.mu_nonneg w.separation w.value_lower

/-- Attainment plus the CONDITIONAL global lower bound. -/
theorem optimality_and_attainment_of_certificate_existence
    (hcert : MissingCertificateExistence) :
    OptimalityStatement ∧
      ∃ (S : Fin 3 → UnitSquare) (o : Point), Packing S o candidateRadius := by
  exact ⟨optimality_of_certificate_existence hcert, exists_packing_at_candidate⟩

end ThreeSquares
