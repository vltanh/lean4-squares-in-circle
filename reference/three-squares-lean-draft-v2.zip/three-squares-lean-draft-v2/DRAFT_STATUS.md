# Revision 2 — exact status

No compilation was requested or performed. No remote proof service was queried.
No numerical Python verifier was executed for this revision.

The new code is in six modules. The unrestricted proof assembly is
`ThreeSquares.Draft.optimality_draft` in `ThreeSquares/DraftMain.lean`.
It is an **uncompiled proof draft containing four explicit admissions**, not a verified theorem.

## Explicit admissions

1. G1 — `normalize_packing`, `GeometricReduction.lean`.
2. G2 — `no_cardinal_chain`, `GeometricReduction.lean`.
3. A1 — `certificate_concave`, `RealCertificateBounds.lean`.
4. A2 — `certificate_formula`, `GeometricReduction.lean`.

These are the only literal `sorry` tactic lines in the Lean source. This textual observation
is not a type check; other proof scripts may fail to elaborate or solve their goals.

## Dependency outline

```
Geometry + Construction                         -> attainment
Geometry + Dual + CenterEstimate                -> center bound
RatDefinitions + Certificates                   -> finite rational checks
TrigIntervals + rational-to-real transfer        -> real endpoint bounds
AngleDomain + Coverage                          -> certificate/triangle selection
A1 + three-point Jensen + endpoint bounds        -> real polynomial lower bound
G1 + G2                                         -> normalized admissible branch
A2 + Dual                                       -> polynomial <= R^2
all of the above                                -> optimality_draft
```

## Suggested first mathematical iteration

A2 is an algebraic equality and can be tackled independently of G1, G2, and A1.
Its source already includes the signed rotated-dot identity needed for the expansion.
This is a proposed work order, not a claim that the remaining identities have been proved.
