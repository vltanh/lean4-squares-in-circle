# Three unit squares in a disk — Lean draft, revision 2

**Uncompiled source draft. Not a completed or verified proof.**
No Lean compiler, Lake build, remote prover, or Python verification was run for this revision.
The new proof assembly uses four explicitly marked `sorry` placeholders, listed below.
All other new theorem bodies are concrete but untested proof scripts. Elaboration, library-name,
and tactic errors may remain even outside the four admitted lemmas.

## Read first

Start with `ThreeSquares/DraftMain.lean`. It assembles the proof of
`ThreeSquares.Draft.optimality_draft : ThreeSquares.OptimalityStatement`.
The original unrestricted `Packing` definition is unchanged. Squares may rotate independently.
The candidate radius is `5 * Real.sqrt 17 / 16`; its square is `425 / 256`.

This revision removes the monolithic `MissingCertificateExistence` parameter from the new
assembly. It does **not** make that missing mathematics disappear: four precise geometric,
algebraic, and analytic lemmas are explicitly admitted instead. The final theorem therefore
depends on `sorryAx` until they are proved, and has not been elaborated at all in this session.

## New modules

| File | Source content |
|---|---|
| `CenterEstimate.lean` | Maximizing vertex, orthonormal-coordinate identity, square-root/absolute-value estimate, and actual packing-center bound. |
| `TrigIntervals.lean` | Exact radical bounds and proof scripts for all twelve sine/cosine endpoint enclosures. No Taylor or Python oracle. |
| `Coverage.lean` | All 48 branch cases and explicit selection of a valid certificate and a supporting triangle, including all five exceptions. |
| `RealCertificateBounds.lean` | Rational-to-real endpoint transfer, curvature arithmetic, three-point Jensen from binary concavity, and triangle lower bounds. |
| `GeometricReduction.lean` | Genuine normalized packing data, exact remaining geometric obligations, cast weight conditions, and rotation identity. |
| `DraftMain.lean` | Certificate selection plus the real dual inequality, then the unrestricted squared-radius lower-bound assembly and attainment. |

The original geometry, construction, dual inequality, 53 rational records, finite arithmetic
checks, and barycentric-cover source files are retained. They too remain uncompiled.

## Four explicit holes

| ID | Lemma | Missing mathematics |
|---|---|---|
| G1 | `Draft.normalize_packing` | Orientation normalization, separating-axis existence, and common cardinal normalization. |
| G2 | `Draft.no_cardinal_chain` | Convert a same-cardinal directed path into the proved numerical chain contradiction. |
| A1 | `RealChecks.certificate_concave` | Whole-domain trigonometric bounds and the second-derivative concavity argument. |
| A2 | `Draft.certificate_formula` | Expand the real dual expression and identify it with the checked rational trigonometric polynomial. |

Each hole has a detailed mathematical proof plan in its source comment. None is claimed to be
proved. Their scope is substantial; this is an iteration draft, not a proof certificate.

## Python verification versus this draft

The finite rational tables have Lean `by decide` proof attempts. Region coverage now uses exact
barycentric witnesses and all 48 cases. The endpoint interval transfer is expressed using real
radical identities, replacing (rather than literally porting) the Python arctangent/Taylor
calculation. These source scripts have not been checked by Lean.

A Python text-generation script emitted `Coverage.lean` from the existing record names. It did
not execute the numerical verifier and does not supply any proof evidence: the generated Lean
propositions are intended to be independently checked by Lean.

## Version and later iteration

The inherited project pins Lean 4.19.0 and mathlib v4.19.0. No compiler setup was attempted.
`AxiomAudit.lean` is provided for a later check; it is expected to show `sorryAx` for the final
assembly while these holes remain. A successful build alone would not remove those admissions.

The previous conditional `Main.lean` and previous README are preserved under `reference/` as
historical text. They do not describe the verification status of this revision.
