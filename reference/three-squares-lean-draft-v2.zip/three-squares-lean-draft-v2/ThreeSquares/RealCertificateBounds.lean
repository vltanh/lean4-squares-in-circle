import ThreeSquares.TrigIntervals
import ThreeSquares.Coverage
import ThreeSquares.Arithmetic

/-!
From exact rational endpoint checks to a real lower bound on a supported triangle.
UNCOMPILED DRAFT. One explicit admission remains: `certificate_concave` (A1).
Everything else in this file has a concrete, untested proof script.
-/
noncomputable section
open scoped BigOperators
namespace ThreeSquares.RealChecks
open RatData AngleDomain Coverage

 def gaps (x : Point) : Fin 3 → ℝ :=
  ![Real.pi * x.1, Real.pi * x.2, Real.pi * (x.2 - x.1)]

def polynomial (c : Certificate) (x : Point) : ℝ :=
  (c.coeff 0 : ℝ) + ∑ e,
    (A c e : ℝ) * Real.cos (gaps x e) + (B c e : ℝ) * Real.sin (gaps x e)

def angleSet : Set Point := {x | Domain x.1 x.2}

lemma corner_mem_angleSet (p : Corner) : cornerPoint p ∈ angleSet := by
  cases p <;> norm_num [angleSet, Domain, cornerPoint, O, V, W, P, Z]

lemma angleSet_convex : Convex ℝ angleSet := by
  intro p hp q hq u v hu hv huv
  rcases hp with ⟨hp0, hp1, hp2⟩
  rcases hq with ⟨hq0, hq1, hq2⟩
  change 0 ≤ u * p.1 + v * q.1 ∧
    2 * (u * p.1 + v * q.1) ≤ u * p.2 + v * q.2 ∧
    2 * (u * p.2 + v * q.2) - (u * p.1 + v * q.1) ≤ 1 / 2
  refine ⟨add_nonneg (mul_nonneg hu hp0) (mul_nonneg hv hq0), ?_, ?_⟩
  · have hp' := mul_le_mul_of_nonneg_left hp1 hu
    have hq' := mul_le_mul_of_nonneg_left hq1 hv
    nlinarith
  · have hp' := mul_le_mul_of_nonneg_left hp2 hu
    have hq' := mul_le_mul_of_nonneg_left hq2 hv
    nlinarith

lemma gap_corner (p : Corner) (e : Fin 3) :
    gaps (cornerPoint p) e = angleReal (cornerAngles p e) := by
  cases p <;> fin_cases e <;>
    norm_num [gaps, cornerPoint, cornerAngles, angleReal, O, V, W, P, Z] <;> ring

lemma termLower_sound (q : ℚ) (I : ℚ × ℚ) (z : ℝ)
    (hz : (I.1 : ℝ) ≤ z ∧ z ≤ (I.2 : ℝ)) :
    (termLower q I : ℝ) ≤ (q : ℝ) * z := by
  by_cases hq : 0 ≤ q
  · simp only [termLower, if_pos hq, Rat.cast_mul]
    exact mul_le_mul_of_nonneg_left hz.1 (by exact_mod_cast hq)
  · simp only [termLower, if_neg hq, Rat.cast_mul]
    have hqr : (q : ℝ) ≤ 0 := by
      exact_mod_cast (le_of_lt (lt_of_not_ge hq))
    exact mul_le_mul_of_nonpos_left hz.2 hqr

lemma valueLower_sound (c : Certificate) (p : Corner) :
    (valueLower c p : ℝ) ≤ polynomial c (cornerPoint p) := by
  unfold valueLower polynomial
  push_cast
  apply add_le_add_left
  apply Finset.sum_le_sum
  intro e _
  rw [gap_corner]
  rcases intervals_sound (cornerAngles p e) with ⟨hcl, hcu, hsl, hsu⟩
  exact add_le_add
    (termLower_sound (A c e) _ _ ⟨hcl, hcu⟩)
    (termLower_sound (B c e) _ _ ⟨hsl, hsu⟩)

lemma checked_corner_lower (c : Certificate) (hc : arithmeticValid c)
    (p : Corner) (hp : p ∈ c.corners) :
    targetSq ≤ polynomial c (cornerPoint p) := by
  rcases hc with ⟨_, _, _, _, _, _, _, _, _, _, hall⟩
  have hOK : cornerOK c p := by
    have hd : decide (cornerOK c p) = true := (List.all_eq_true.mp hall) p hp
    exact of_decide_eq_true hd
  have hrat : (425 / 256 : ℚ) ≤ valueLower c p := by
    by_cases hO : p = .O
    · have hbase : c.isBase = true ∧ valueLower c p = 425 / 256 := by
        simpa only [cornerOK, if_pos hO] using hOK
      exact le_of_eq hbase.2.symm
    · have hgt : (425 / 256 + 1 / 250 : ℚ) < valueLower c p := by
        simpa only [cornerOK, if_neg hO] using hOK
      linarith
  have hcast : targetSq ≤ (valueLower c p : ℝ) := by
    unfold targetSq
    exact_mod_cast hrat
  exact hcast.trans (valueLower_sound c p)

/-- The rational minor tests imply the real quadratic-form inequality. -/
lemma checked_hessian (c : Certificate) (hc : arithmeticValid c)
    (g : Fin 3 → ℝ) (hg : ∀ e, (curvatureLower c e : ℝ) ≤ g e)
    (u v : ℝ) : 0 ≤ g 0 * u ^ 2 + g 1 * v ^ 2 + g 2 * (v - u) ^ 2 := by
  rcases hc with ⟨_, _, _, _, _, _, _, hA, _, hdet, _⟩
  have hA' : (1 / 3 : ℝ) <
      (curvatureLower c 0 : ℝ) + (curvatureLower c 2 : ℝ) := by
    exact_mod_cast hA
  have hd' : (3 / 40 : ℝ) <
      (curvatureLower c 0 : ℝ) * (curvatureLower c 1 : ℝ) +
      (curvatureLower c 0 : ℝ) * (curvatureLower c 2 : ℝ) +
      (curvatureLower c 1 : ℝ) * (curvatureLower c 2 : ℝ) := by
    exact_mod_cast hdet
  exact hessian_nonneg _ _ _ _ _ _ u v (hg 0) (hg 1) (hg 2)
    (by linarith) (by linarith)

/--
DRAFT_HOLE A1 (real analysis).
Prove the interval inequalities on the WHOLE angle triangle, not only its vertices:
  cos(a) ≥ 6/7, cos(b) ≥ 1/2, cos(b-a) ≥ 7/10;
  0 ≤ sin(a) ≤ 1/2, 0 ≤ sin(b) ≤ 7/8, 0 ≤ sin(b-a) ≤ 3/4.
Then for g_e = A_e cos(delta_e) + B_e sin(delta_e), use `checked_hessian`.
Along any segment x+t(y-x), the second derivative of `polynomial c` is
  -pi^2 * (g_0*u^2 + g_1*v^2 + g_2*(v-u)^2), where (u,v)=y-x.
It is nonpositive; the one-dimensional second-derivative concavity criterion
and `angleSet_convex` finish. The pi^2 factor is needed because x is measured
in multiples of pi.
-/
lemma certificate_concave (c : Certificate) (hc : arithmeticValid c) :
    ConcaveOn ℝ angleSet (polynomial c) := by
  sorry

/-- Three-point Jensen, proved directly from the binary definition of concavity. -/
lemma concave_triangle_lower {f : Point → ℝ} {K : ℝ}
    (hf : ConcaveOn ℝ angleSet f) {p q r x : Point}
    (hp : p ∈ angleSet) (hq : q ∈ angleSet) (hr : r ∈ angleSet)
    (hfp : K ≤ f p) (hfq : K ≤ f q) (hfr : K ≤ f r)
    (hx : InTriangle p q r x) : K ≤ f x := by
  rcases hx with ⟨u, v, w, hu, hv, hw, hsum, hx1, hx2⟩
  by_cases hzero : v + w = 0
  · have hv0 : v = 0 := by linarith
    have hw0 : w = 0 := by linarith
    have hu1 : u = 1 := by linarith
    have heq : x = p := by
      apply Prod.ext
      · simpa [hv0, hw0, hu1] using hx1
      · simpa [hv0, hw0, hu1] using hx2
    simpa [heq] using hfp
  · have ht : 0 < v + w := lt_of_le_of_ne (add_nonneg hv hw) (Ne.symm hzero)
    have hv' : 0 ≤ v / (v + w) := div_nonneg hv ht.le
    have hw' : 0 ≤ w / (v + w) := div_nonneg hw ht.le
    have hsum' : v / (v + w) + w / (v + w) = 1 := by
      field_simp [hzero] <;> ring
    let z : Point := (v / (v + w)) • q + (w / (v + w)) • r
    have hz : z ∈ angleSet := hf.1 hq hr hv' hw' hsum'
    have hzJ := hf.2 hq hr hv' hw' hsum'
    change (v / (v + w)) * f q + (w / (v + w)) * f r ≤ f z at hzJ
    have hzF : K ≤ f z := by
      have hq' := mul_le_mul_of_nonneg_left hfq hv'
      have hr' := mul_le_mul_of_nonneg_left hfr hw'
      nlinarith
    have heq : x = u • p + (v + w) • z := by
      apply Prod.ext
      · change x.1 = u * p.1 + (v + w) *
          ((v / (v + w)) * q.1 + (w / (v + w)) * r.1)
        calc
          _ = u * p.1 + v * q.1 + w * r.1 := hx1
          _ = _ := by field_simp [hzero] <;> ring
      · change x.2 = u * p.2 + (v + w) *
          ((v / (v + w)) * q.2 + (w / (v + w)) * r.2)
        calc
          _ = u * p.2 + v * q.2 + w * r.2 := hx2
          _ = _ := by field_simp [hzero] <;> ring
    have hJ := hf.2 hp hz hu ht.le (show u + (v + w) = 1 by linarith)
    change u * f p + (v + w) * f z ≤ f (u • p + (v + w) • z) at hJ
    rw [← heq] at hJ
    have hp' := mul_le_mul_of_nonneg_left hfp hu
    have hz' := mul_le_mul_of_nonneg_left hzF ht.le
    nlinarith

lemma certificate_triangle_lower (c : Certificate) (hc : arithmeticValid c)
    (p q r : Corner) (hs : Supports c p q r) {x : Point}
    (hx : InTriangle (cornerPoint p) (cornerPoint q) (cornerPoint r) x) :
    targetSq ≤ polynomial c x := by
  exact concave_triangle_lower (certificate_concave c hc)
    (corner_mem_angleSet p) (corner_mem_angleSet q) (corner_mem_angleSet r)
    (checked_corner_lower c hc p hs.1)
    (checked_corner_lower c hc q hs.2.1)
    (checked_corner_lower c hc r hs.2.2) hx

end ThreeSquares.RealChecks
