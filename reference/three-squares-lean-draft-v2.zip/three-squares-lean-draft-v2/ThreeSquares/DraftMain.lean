import ThreeSquares.Construction
import ThreeSquares.GeometricReduction

/-!
End-to-end proof ASSEMBLY, not a verified proof.
UNCOMPILED DRAFT. Its dependencies include the four explicitly admitted lemmas
G1 normalize_packing, G2 no_cardinal_chain, A1 certificate_concave,
and A2 certificate_formula. There is no MissingCertificateExistence parameter.
The missing work has not disappeared: it is exposed in those four lemmas.
-/
noncomputable section
namespace ThreeSquares.Draft
open RatData Coverage RealChecks

/-- Combine an actual selected certificate with containment and separation. -/
theorem normalized_squared_lower {R : ℝ} (N : NormalizedPacking R)
    (hR : R ^ 2 ≤ targetSq) : targetSq ≤ R ^ 2 := by
  obtain ⟨c, p, q, r, hc, hmatch, hsupport, htriangle⟩ :=
    Coverage.select N.in_domain (N.k 1) (N.k 2)
      (N.source 0) (N.source 1) (N.source 2)
      (normalized_pattern N hR) (normalized_sources N)
  have hlower : targetSq ≤ polynomial c N.x :=
    certificate_triangle_lower c hc p q r hsupport htriangle
  rcases checked_weights c hc with ⟨hl, hsum, hw, hm⟩
  have hsep : ∀ e, widths N.x e ≤ dot (normals N.x N.k N.source e)
      (sub (sub (squares N.centers N.x (edgeEnd e)).center (0,0))
        (sub (squares N.centers N.x (edgeStart e)).center (0,0))) := by
    intro e
    simpa [squares, angleSquare, sub] using N.separation e
  have hupper := packing_dual_bound N.packing
    (normals N.x N.k N.source) (realLam c) (realMu c) (widths N.x)
    hl hsum hw hm hsep
  rw [certificate_formula N c hc hmatch] at hupper
  exact hlower.trans hupper

/-- UNCOMPILED; depends on all four listed admissions. -/
theorem optimality_draft : OptimalityStatement := by
  intro S o R hp
  apply radius_lower_of_squared hp.1
  by_cases hbig : targetSq ≤ R ^ 2
  · exact hbig
  · obtain ⟨N⟩ := normalize_packing hp
    exact normalized_squared_lower N (le_of_lt (lt_of_not_ge hbig))

/-- Attainment and the global lower bound, subject to the same four draft holes. -/
theorem optimality_and_attainment_draft :
    OptimalityStatement ∧
      ∃ (S : Fin 3 → UnitSquare) (o : Point), Packing S o candidateRadius := by
  exact ⟨optimality_draft, exists_packing_at_candidate⟩

end ThreeSquares.Draft
