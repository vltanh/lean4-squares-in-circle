import ThreeSquares.Dual
import ThreeSquares.Arithmetic

/-!
A coordinate proof of the geometric center estimate, not just its algebraic end step.
UNCOMPILED DRAFT. All theorem bodies in this file are proof attempts, with no admissions.
-/
noncomputable section
namespace ThreeSquares

/-- The two components of a center in the square's orthonormal frame. -/
def centerCoordinates (S : UnitSquare) (c : Point) : Point :=
  (S.cosine * c.1 + S.sine * c.2,
   -S.sine * c.1 + S.cosine * c.2)

lemma centerCoordinates_norm (S : UnitSquare) (c : Point) :
    normSq (centerCoordinates S c) = normSq c := by
  calc
    _ = (S.cosine ^ 2 + S.sine ^ 2) * normSq c := by
      dsimp [centerCoordinates, normSq]
      ring
    _ = normSq c := by rw [S.unit]; ring

/-- Select signs attaining both absolute values in the farthest-vertex formula. -/
lemma maximizing_vertex (S : UnitSquare) (c : Point) :
    ∃ j : Fin 4, 2 * dot c (rotate S (localVertex j)) =
      |(centerCoordinates S c).1| + |(centerCoordinates S c).2| := by
  let X := (centerCoordinates S c).1
  let Y := (centerCoordinates S c).2
  have expand (j : Fin 4) :
      dot c (rotate S (localVertex j)) =
        X * (localVertex j).1 + Y * (localVertex j).2 := by
    dsimp [X, Y, centerCoordinates, dot, rotate]
    ring
  change ∃ j : Fin 4, 2 * dot c (rotate S (localVertex j)) = |X| + |Y|
  by_cases hx : 0 ≤ X <;> by_cases hy : 0 ≤ Y
  · refine ⟨3, ?_⟩
    rw [expand, abs_of_nonneg hx, abs_of_nonneg hy]
    norm_num [localVertex]
    <;> ring
  · refine ⟨2, ?_⟩
    rw [expand, abs_of_nonneg hx, abs_of_neg (lt_of_not_ge hy)]
    norm_num [localVertex]
    <;> ring
  · refine ⟨1, ?_⟩
    rw [expand, abs_of_neg (lt_of_not_ge hx), abs_of_nonneg hy]
    norm_num [localVertex]
    <;> ring
  · refine ⟨0, ?_⟩
    rw [expand, abs_of_neg (lt_of_not_ge hx), abs_of_neg (lt_of_not_ge hy)]
    norm_num [localVertex]
    <;> ring

lemma sqrt_norm_le_abs_coordinates (S : UnitSquare) (c : Point) :
    Real.sqrt (normSq c) ≤
      |(centerCoordinates S c).1| + |(centerCoordinates S c).2| := by
  have hn := Real.sqrt_nonneg (normSq c)
  have hs := Real.sq_sqrt (normSq_nonneg c)
  have hc := centerCoordinates_norm S c
  have hx := sq_abs (centerCoordinates S c).1
  have hy := sq_abs (centerCoordinates S c).2
  have hxy := mul_nonneg (abs_nonneg (centerCoordinates S c).1)
    (abs_nonneg (centerCoordinates S c).2)
  have hsum := add_nonneg (abs_nonneg (centerCoordinates S c).1)
    (abs_nonneg (centerCoordinates S c).2)
  dsimp [normSq] at hc
  nlinarith

lemma center_radius_inequality {S : Fin 3 → UnitSquare} {o : Point} {R : ℝ}
    (hp : Packing S o R) (i : Fin 3) :
    normSq (sub (S i).center o) +
      Real.sqrt (normSq (sub (S i).center o)) + 1 / 2 ≤ R ^ 2 := by
  let c := sub (S i).center o
  obtain ⟨j, hj⟩ := maximizing_vertex (S i) c
  have hv := packing_vertex_bound hp i j
  change normSq (add c (rotate (S i) (localVertex j))) ≤ R ^ 2 at hv
  rw [normSq_add, normSq_rotate, localVertex_normSq, hj] at hv
  have hcoord := sqrt_norm_le_abs_coordinates (S i) c
  change normSq c + Real.sqrt (normSq c) + 1 / 2 ≤ R ^ 2
  linarith

/-- Every center of a packing at or below the candidate radius lies in this disk. -/
theorem packing_center_bound {S : Fin 3 → UnitSquare} {o : Point} {R : ℝ}
    (hp : Packing S o R) (hR : R ^ 2 ≤ targetSq) (i : Fin 3) :
    Real.sqrt (normSq (sub (S i).center o)) ≤ 11 / 16 := by
  have h := (center_radius_inequality hp i).trans hR
  have hs := Real.sq_sqrt (normSq_nonneg (sub (S i).center o))
  apply center_bound_algebra (Real.sqrt_nonneg _)
  nlinarith

end ThreeSquares
