import ThreeSquares.Certificates
import ThreeSquares.AngleDomain

/-!
Explicit selection of a certificate and a triangle for every branch and every point.
The quadrilateral in the last exceptional branch is split into two triangles.
Text was generated from the existing certificate record names; proof bodies use
Lean's ordinary `decide` and the barycentric proofs in AngleDomain, not Python checks.
UNCOMPILED DRAFT.
-/
noncomputable section
namespace ThreeSquares.Coverage
open RatData AngleDomain

 def cornerPoint : Corner → Point
  | .O => O
  | .V => V
  | .W => W
  | .P => P
  | .Z => Z

def Matches (c : Certificate) (k02 k12 : Fin 4) (s0 s1 s2 : Fin 3) : Prop :=
  c.k 1 = k02 ∧ c.k 2 = k12 ∧
  c.source 0 = s0 ∧ c.source 1 = s1 ∧ c.source 2 = s2

instance (c : Certificate) (k02 k12 : Fin 4) (s0 s1 s2 : Fin 3) :
    Decidable (Matches c k02 k12 s0 s1 s2) := by
  unfold Matches
  infer_instance

def Supports (c : Certificate) (p q r : Corner) : Prop :=
  p ∈ c.corners ∧ q ∈ c.corners ∧ r ∈ c.corners

instance (c : Certificate) (p q r : Corner) : Decidable (Supports c p q r) := by
  unfold Supports
  infer_instance

set_option maxRecDepth 200000
set_option maxHeartbeats 0

lemma admissible_cases : ∀ k02 k12 : Fin 4,
    ∀ s0 s1 s2 : Fin 3,
    (k02, k12) ∈ Combinatorics.remaining →
    (s0, s1, s2) ∈ Combinatorics.sources →
    (k02 = 0 ∧ k12 = 1 ∧ s0 = 0 ∧ s1 = 0 ∧ s2 = 1) ∨
    (k02 = 0 ∧ k12 = 1 ∧ s0 = 0 ∧ s1 = 0 ∧ s2 = 2) ∨
    (k02 = 0 ∧ k12 = 1 ∧ s0 = 0 ∧ s1 = 2 ∧ s2 = 1) ∨
    (k02 = 0 ∧ k12 = 1 ∧ s0 = 0 ∧ s1 = 2 ∧ s2 = 2) ∨
    (k02 = 0 ∧ k12 = 1 ∧ s0 = 1 ∧ s1 = 0 ∧ s2 = 1) ∨
    (k02 = 0 ∧ k12 = 1 ∧ s0 = 1 ∧ s1 = 0 ∧ s2 = 2) ∨
    (k02 = 0 ∧ k12 = 1 ∧ s0 = 1 ∧ s1 = 2 ∧ s2 = 1) ∨
    (k02 = 0 ∧ k12 = 1 ∧ s0 = 1 ∧ s1 = 2 ∧ s2 = 2) ∨
    (k02 = 0 ∧ k12 = 3 ∧ s0 = 0 ∧ s1 = 0 ∧ s2 = 1) ∨
    (k02 = 0 ∧ k12 = 3 ∧ s0 = 0 ∧ s1 = 0 ∧ s2 = 2) ∨
    (k02 = 0 ∧ k12 = 3 ∧ s0 = 0 ∧ s1 = 2 ∧ s2 = 1) ∨
    (k02 = 0 ∧ k12 = 3 ∧ s0 = 0 ∧ s1 = 2 ∧ s2 = 2) ∨
    (k02 = 0 ∧ k12 = 3 ∧ s0 = 1 ∧ s1 = 0 ∧ s2 = 1) ∨
    (k02 = 0 ∧ k12 = 3 ∧ s0 = 1 ∧ s1 = 0 ∧ s2 = 2) ∨
    (k02 = 0 ∧ k12 = 3 ∧ s0 = 1 ∧ s1 = 2 ∧ s2 = 1) ∨
    (k02 = 0 ∧ k12 = 3 ∧ s0 = 1 ∧ s1 = 2 ∧ s2 = 2) ∨
    (k02 = 1 ∧ k12 = 1 ∧ s0 = 0 ∧ s1 = 0 ∧ s2 = 1) ∨
    (k02 = 1 ∧ k12 = 1 ∧ s0 = 0 ∧ s1 = 0 ∧ s2 = 2) ∨
    (k02 = 1 ∧ k12 = 1 ∧ s0 = 0 ∧ s1 = 2 ∧ s2 = 1) ∨
    (k02 = 1 ∧ k12 = 1 ∧ s0 = 0 ∧ s1 = 2 ∧ s2 = 2) ∨
    (k02 = 1 ∧ k12 = 1 ∧ s0 = 1 ∧ s1 = 0 ∧ s2 = 1) ∨
    (k02 = 1 ∧ k12 = 1 ∧ s0 = 1 ∧ s1 = 0 ∧ s2 = 2) ∨
    (k02 = 1 ∧ k12 = 1 ∧ s0 = 1 ∧ s1 = 2 ∧ s2 = 1) ∨
    (k02 = 1 ∧ k12 = 1 ∧ s0 = 1 ∧ s1 = 2 ∧ s2 = 2) ∨
    (k02 = 1 ∧ k12 = 2 ∧ s0 = 0 ∧ s1 = 0 ∧ s2 = 1) ∨
    (k02 = 1 ∧ k12 = 2 ∧ s0 = 0 ∧ s1 = 0 ∧ s2 = 2) ∨
    (k02 = 1 ∧ k12 = 2 ∧ s0 = 0 ∧ s1 = 2 ∧ s2 = 1) ∨
    (k02 = 1 ∧ k12 = 2 ∧ s0 = 0 ∧ s1 = 2 ∧ s2 = 2) ∨
    (k02 = 1 ∧ k12 = 2 ∧ s0 = 1 ∧ s1 = 0 ∧ s2 = 1) ∨
    (k02 = 1 ∧ k12 = 2 ∧ s0 = 1 ∧ s1 = 0 ∧ s2 = 2) ∨
    (k02 = 1 ∧ k12 = 2 ∧ s0 = 1 ∧ s1 = 2 ∧ s2 = 1) ∨
    (k02 = 1 ∧ k12 = 2 ∧ s0 = 1 ∧ s1 = 2 ∧ s2 = 2) ∨
    (k02 = 3 ∧ k12 = 2 ∧ s0 = 0 ∧ s1 = 0 ∧ s2 = 1) ∨
    (k02 = 3 ∧ k12 = 2 ∧ s0 = 0 ∧ s1 = 0 ∧ s2 = 2) ∨
    (k02 = 3 ∧ k12 = 2 ∧ s0 = 0 ∧ s1 = 2 ∧ s2 = 1) ∨
    (k02 = 3 ∧ k12 = 2 ∧ s0 = 0 ∧ s1 = 2 ∧ s2 = 2) ∨
    (k02 = 3 ∧ k12 = 2 ∧ s0 = 1 ∧ s1 = 0 ∧ s2 = 1) ∨
    (k02 = 3 ∧ k12 = 2 ∧ s0 = 1 ∧ s1 = 0 ∧ s2 = 2) ∨
    (k02 = 3 ∧ k12 = 2 ∧ s0 = 1 ∧ s1 = 2 ∧ s2 = 1) ∨
    (k02 = 3 ∧ k12 = 2 ∧ s0 = 1 ∧ s1 = 2 ∧ s2 = 2) ∨
    (k02 = 3 ∧ k12 = 3 ∧ s0 = 0 ∧ s1 = 0 ∧ s2 = 1) ∨
    (k02 = 3 ∧ k12 = 3 ∧ s0 = 0 ∧ s1 = 0 ∧ s2 = 2) ∨
    (k02 = 3 ∧ k12 = 3 ∧ s0 = 0 ∧ s1 = 2 ∧ s2 = 1) ∨
    (k02 = 3 ∧ k12 = 3 ∧ s0 = 0 ∧ s1 = 2 ∧ s2 = 2) ∨
    (k02 = 3 ∧ k12 = 3 ∧ s0 = 1 ∧ s1 = 0 ∧ s2 = 1) ∨
    (k02 = 3 ∧ k12 = 3 ∧ s0 = 1 ∧ s1 = 0 ∧ s2 = 2) ∨
    (k02 = 3 ∧ k12 = 3 ∧ s0 = 1 ∧ s1 = 2 ∧ s2 = 1) ∨
    (k02 = 3 ∧ k12 = 3 ∧ s0 = 1 ∧ s1 = 2 ∧ s2 = 2) := by
  decide

theorem select {x : Point} (hD : Domain x.1 x.2)
    (k02 k12 : Fin 4) (s0 s1 s2 : Fin 3)
    (hk : (k02, k12) ∈ Combinatorics.remaining)
    (hs : (s0, s1, s2) ∈ Combinatorics.sources) :
    ∃ (c : Certificate) (p q r : Corner),
      arithmeticValid c ∧ Matches c k02 k12 s0 s1 s2 ∧ Supports c p q r ∧
      InTriangle (cornerPoint p) (cornerPoint q) (cornerPoint r) x := by
  rcases admissible_cases k02 k12 s0 s1 s2 hk hs with
    h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert000, .O, .V, .W, cert000_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert001, .O, .V, .W, cert001_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert002, .O, .V, .W, cert002_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert003, .O, .V, .W, cert003_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert004, .O, .V, .W, cert004_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert005, .O, .V, .W, cert005_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert006, .O, .V, .W, cert006_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert007, .O, .V, .W, cert007_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert008, .O, .V, .W, cert008_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert009, .O, .V, .W, cert009_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert010, .O, .V, .W, cert010_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert011, .O, .V, .W, cert011_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    rcases cover_G hD with hbase | hextra
    · refine ⟨cert012, .O, .V, .Z, cert012_checked, by decide, by decide, ?_⟩
      simpa only [cornerPoint, Prod.eta] using hbase
    · refine ⟨cert013, .V, .W, .Z, cert013_checked, by decide, by decide, ?_⟩
      simpa only [cornerPoint, Prod.eta] using hextra
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert014, .O, .V, .W, cert014_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert015, .O, .V, .W, cert015_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert016, .O, .V, .W, cert016_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert017, .O, .V, .W, cert017_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    rcases cover_H hD with hbase | hextra
    · refine ⟨cert018, .O, .P, .W, cert018_checked, by decide, by decide, ?_⟩
      simpa only [cornerPoint, Prod.eta] using hbase
    · refine ⟨cert019, .P, .V, .W, cert019_checked, by decide, by decide, ?_⟩
      simpa only [cornerPoint, Prod.eta] using hextra
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert020, .O, .V, .W, cert020_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert021, .O, .V, .W, cert021_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert022, .O, .V, .W, cert022_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    rcases cover_H hD with hbase | hextra
    · refine ⟨cert023, .O, .P, .W, cert023_checked, by decide, by decide, ?_⟩
      simpa only [cornerPoint, Prod.eta] using hbase
    · refine ⟨cert024, .P, .V, .W, cert024_checked, by decide, by decide, ?_⟩
      simpa only [cornerPoint, Prod.eta] using hextra
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert025, .O, .V, .W, cert025_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert026, .O, .V, .W, cert026_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert027, .O, .V, .W, cert027_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert028, .O, .V, .W, cert028_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert029, .O, .V, .W, cert029_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert030, .O, .V, .W, cert030_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert031, .O, .V, .W, cert031_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert032, .O, .V, .W, cert032_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert033, .O, .V, .W, cert033_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert034, .O, .V, .W, cert034_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert035, .O, .V, .W, cert035_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert036, .O, .V, .W, cert036_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert037, .O, .V, .W, cert037_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert038, .O, .V, .W, cert038_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert039, .O, .V, .W, cert039_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert040, .O, .V, .W, cert040_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert041, .O, .V, .W, cert041_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert042, .O, .V, .W, cert042_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert043, .O, .V, .W, cert043_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert044, .O, .V, .W, cert044_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    rcases cover_H hD with hbase | hextra
    · refine ⟨cert045, .O, .P, .W, cert045_checked, by decide, by decide, ?_⟩
      simpa only [cornerPoint, Prod.eta] using hbase
    · refine ⟨cert046, .P, .V, .W, cert046_checked, by decide, by decide, ?_⟩
      simpa only [cornerPoint, Prod.eta] using hextra
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert047, .O, .V, .W, cert047_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert048, .O, .V, .W, cert048_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert049, .O, .V, .W, cert049_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    rcases cover_J_special hD with hbase | hextra₁ | hextra₂
    · refine ⟨cert050, .O, .P, .Z, cert050_checked, by decide, by decide, ?_⟩
      simpa only [cornerPoint, Prod.eta] using hbase
    · refine ⟨cert051, .P, .V, .W, cert051_checked, by decide, by decide, ?_⟩
      simpa only [cornerPoint, Prod.eta] using hextra₁
    · refine ⟨cert051, .P, .W, .Z, cert051_checked, by decide, by decide, ?_⟩
      simpa only [cornerPoint, Prod.eta] using hextra₂
  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩
    refine ⟨cert052, .O, .V, .W, cert052_checked, by decide, by decide, ?_⟩
    simpa only [cornerPoint, Prod.eta] using (in_full hD)

end ThreeSquares.Coverage
