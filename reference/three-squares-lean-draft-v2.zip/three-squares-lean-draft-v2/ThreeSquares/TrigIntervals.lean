import ThreeSquares.RatDefinitions

/-!
Proof attempts for all real endpoint enclosures used by the rational certificates.
No Python result, decimal floating-point calculation, or Taylor-series oracle is used.
The endpoints are special angles, so exact radical identities suffice.
UNCOMPILED DRAFT: mathlib names and tactic elaboration have not been checked.
-/
noncomputable section
namespace ThreeSquares.RealChecks
open RatData

 def angleReal : Angle → ℝ
  | .zero => 0
  | .a15 => Real.pi / 12
  | .a22_5 => Real.pi / 8
  | .a30 => Real.pi / 6
  | .a45 => Real.pi / 4
  | .a60 => Real.pi / 3

lemma sqrt_sandwich {x lo hi : ℝ} (hx : 0 ≤ x)
    (hl : 0 ≤ lo) (hh : 0 ≤ hi) (hls : lo ^ 2 ≤ x) (hhs : x ≤ hi ^ 2) :
    lo ≤ Real.sqrt x ∧ Real.sqrt x ≤ hi := by
  have h0 := Real.sqrt_nonneg x
  have h2 := Real.sq_sqrt hx
  constructor <;> nlinarith

lemma sqrt2_bounds : (141421356 / 100000000 : ℝ) ≤ Real.sqrt 2 ∧
    Real.sqrt 2 ≤ 141421357 / 100000000 := by
  apply sqrt_sandwich <;> norm_num

lemma sqrt3_bounds : (173205080 / 100000000 : ℝ) ≤ Real.sqrt 3 ∧
    Real.sqrt 3 ≤ 173205081 / 100000000 := by
  apply sqrt_sandwich <;> norm_num

lemma sqrt6_bounds : (244948974 / 100000000 : ℝ) ≤ Real.sqrt 6 ∧
    Real.sqrt 6 ≤ 244948975 / 100000000 := by
  apply sqrt_sandwich <;> norm_num

lemma sqrt_two_mul_three : Real.sqrt 2 * Real.sqrt 3 = Real.sqrt 6 := by
  rw [← Real.sqrt_mul (show (0 : ℝ) ≤ 2 by norm_num)]
  norm_num

lemma sin_twelve : Real.sin (Real.pi / 12) =
    (Real.sqrt 6 - Real.sqrt 2) / 4 := by
  rw [show Real.pi / 12 = Real.pi / 4 - Real.pi / 6 by ring,
    Real.sin_sub, Real.sin_pi_div_four, Real.cos_pi_div_six,
    Real.cos_pi_div_four, Real.sin_pi_div_six]
  calc
    _ = (Real.sqrt 2 * Real.sqrt 3 - Real.sqrt 2) / 4 := by ring
    _ = _ := by rw [sqrt_two_mul_three]

lemma cos_twelve : Real.cos (Real.pi / 12) =
    (Real.sqrt 6 + Real.sqrt 2) / 4 := by
  rw [show Real.pi / 12 = Real.pi / 4 - Real.pi / 6 by ring,
    Real.cos_sub, Real.cos_pi_div_four, Real.cos_pi_div_six,
    Real.sin_pi_div_four, Real.sin_pi_div_six]
  calc
    _ = (Real.sqrt 2 * Real.sqrt 3 + Real.sqrt 2) / 4 := by ring
    _ = _ := by rw [sqrt_two_mul_three]

lemma eighth_radical_bounds :
    (2 * (923879 / 1000000 : ℝ) ≤ Real.sqrt (2 + Real.sqrt 2) ∧
      Real.sqrt (2 + Real.sqrt 2) ≤ 2 * (923880 / 1000000)) ∧
    (2 * (382683 / 1000000 : ℝ) ≤ Real.sqrt (2 - Real.sqrt 2) ∧
      Real.sqrt (2 - Real.sqrt 2) ≤ 2 * (382684 / 1000000)) := by
  rcases sqrt2_bounds with ⟨hl, hu⟩
  constructor
  · apply sqrt_sandwich <;> norm_num <;> linarith
  · apply sqrt_sandwich <;> norm_num <;> linarith

/-- Both interval endpoints are exact rational casts into the real numbers. -/
theorem intervals_sound (t : Angle) :
    ((cosInterval t).1 : ℝ) ≤ Real.cos (angleReal t) ∧
    Real.cos (angleReal t) ≤ ((cosInterval t).2 : ℝ) ∧
    ((sinInterval t).1 : ℝ) ≤ Real.sin (angleReal t) ∧
    Real.sin (angleReal t) ≤ ((sinInterval t).2 : ℝ) := by
  rcases sqrt2_bounds with ⟨h2l, h2u⟩
  rcases sqrt3_bounds with ⟨h3l, h3u⟩
  rcases sqrt6_bounds with ⟨h6l, h6u⟩
  rcases eighth_radical_bounds with ⟨⟨hcl, hcu⟩, ⟨hsl, hsu⟩⟩
  cases t <;>
    norm_num [angleReal, cosInterval, sinInterval,
      sin_twelve, cos_twelve, Real.sin_pi_div_eight, Real.cos_pi_div_eight,
      Real.sin_pi_div_six, Real.cos_pi_div_six,
      Real.sin_pi_div_four, Real.cos_pi_div_four,
      Real.sin_pi_div_three, Real.cos_pi_div_three] <;>
    (repeat' constructor) <;> nlinarith

end ThreeSquares.RealChecks
