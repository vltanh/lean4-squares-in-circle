import ThreeSquares.DraftMain

/-! Uncompiled draft entry point. See DRAFT_STATUS.md for all four explicit admissions. -/
