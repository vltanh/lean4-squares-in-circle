import ThreeSquares.CenterEstimate
import ThreeSquares.RealCertificateBounds

/-!
Precise interfaces between geometric packings and the finite certificate proof.
UNCOMPILED DRAFT. Three admissions are explicitly labeled G1, G2, and A2.
None of the definitions assumes optimality or a lower bound on the certificate.
-/
noncomputable section
open scoped BigOperators
namespace ThreeSquares.Draft
open RatData AngleDomain Coverage RealChecks

 def theta (x : Point) : Fin 3 → ℝ := ![0, Real.pi * x.1, Real.pi * x.2]

def angleSquare (c : Point) (t : ℝ) : UnitSquare where
  center := c
  cosine := Real.cos t
  sine := Real.sin t
  unit := by nlinarith [Real.sin_sq_add_cos_sq t]

def squares (centers : Fin 3 → Point) (x : Point) (i : Fin 3) : UnitSquare :=
  angleSquare (centers i) (theta x i)

def cardinal (k : Fin 4) : Point :=
  ((RatData.dirs k).1, (RatData.dirs k).2)

def normals (x : Point) (k : Fin 3 → Fin 4) (source : Fin 3 → Fin 3)
    (e : Fin 3) : Point :=
  rotate (angleSquare (0, 0) (theta x (source e))) (cardinal (k e))

def widths (x : Point) (e : Fin 3) : ℝ :=
  (1 + Real.cos (gaps x e) + Real.sin (gaps x e)) / 2

/-- A genuine, normalized geometric packing with explicit separating axes. -/
structure NormalizedPacking (R : ℝ) where
  centers : Fin 3 → Point
  x : Point
  in_domain : Domain x.1 x.2
  k : Fin 3 → Fin 4
  source : Fin 3 → Fin 3
  k_zero : k 0 = 0
  source_valid : ∀ e, source e = RatData.first e ∨ source e = RatData.last e
  packing : Packing (squares centers x) (0, 0) R
  separation : ∀ e, widths x e ≤ dot (normals x k source e)
    (sub (centers (edgeEnd e)) (centers (edgeStart e)))

/--
DRAFT_HOLE G1 (normalization and separating axes).
1. Translate the disk center to the origin.
2. Represent each square frame modulo pi/2, cut at a largest orientation gap,
   relabel and reflect to obtain 0 <= 2*a <= b and 2*b-a <= pi/2.
3. Use the polygon separating-axis theorem, proved from disjoint OPEN interiors,
   to choose a signed edge normal from one of each pair of squares.
4. A common quarter turn sets k_01=0; reindex each square's four vertices when
   bringing its frame back to the chosen representative.
The conclusion contains ONLY geometric containment and separating inequalities.
There is no certificate-existence or optimum hypothesis hidden in this interface.
-/
theorem normalize_packing {S : Fin 3 → UnitSquare} {o : Point} {R : ℝ}
    (hp : Packing S o R) : Nonempty (NormalizedPacking R) := by
  sorry

/--
DRAFT_HOLE G2 (forbidden chain).
For the two directed edges in a chain, let phi be the angular separation of
its normals and L the sum of the required widths. With rho=11/16:
  L <= rho * (2 + ||n1-n2||) <= 11/8 + (11/16)*phi;
  L >= 2 + (7/44)*phi;  phi <= pi/3 < 22/21.
The first line uses `packing_center_bound` below; the second uses the chord
minorant of h(t)=(1+cos(t)+sin(t))/2 and the triangle inequality for angles.
Apply `chain_contradiction`. A reversed edge changes its cardinal index by 2.
-/
theorem no_cardinal_chain {R : ℝ} (N : NormalizedPacking R)
    (hR : R ^ 2 ≤ targetSq) : ¬ Combinatorics.hasChain (N.k 1) (N.k 2) := by
  have hcenters (i : Fin 3) : Real.sqrt (normSq (N.centers i)) ≤ 11 / 16 := by
    have h := packing_center_bound N.packing hR i
    simpa [squares, angleSquare, sub] using h
  intro hchain
  rcases hchain with ⟨i, j, k, hij, hjk, hik, hdirection⟩
  -- Apply the two selected separating inequalities, reversing signs where needed.
  -- Then use the common-cardinal condition `hdirection` and the estimates above.
  sorry

lemma normalized_pattern {R : ℝ} (N : NormalizedPacking R)
    (hR : R ^ 2 ≤ targetSq) : (N.k 1, N.k 2) ∈ Combinatorics.remaining := by
  exact (Combinatorics.classification _ _).mp (no_cardinal_chain N hR)

lemma normalized_sources {R : ℝ} (N : NormalizedPacking R) :
    (N.source 0, N.source 1, N.source 2) ∈ Combinatorics.sources := by
  apply (Combinatorics.source_classification _ _ _).mp
  exact ⟨by simpa [RatData.first, RatData.last] using N.source_valid 0,
    by simpa [RatData.first, RatData.last] using N.source_valid 1,
    by simpa [RatData.first, RatData.last] using N.source_valid 2⟩

def realLam (c : Certificate) (i : Fin 3) (j : Fin 4) : ℝ := c.lam i j

def realMu (c : Certificate) (e : Fin 3) : ℝ := c.mu e

lemma checked_weights (c : Certificate) (hc : arithmeticValid c) :
    (∀ i j, 0 ≤ realLam c i j) ∧
    (∑ i, ∑ j, realLam c i j) = 1 ∧
    (∀ i, 0 < mass (realLam c i)) ∧ (∀ e, 0 ≤ realMu c e) := by
  rcases hc with ⟨_, _, hl, hs, hw, hm, _⟩
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro i j
    dsimp [realLam]
    exact_mod_cast hl i j
  · dsimp [realLam]
    exact_mod_cast hs
  · intro i
    dsimp [mass, realLam]
    have h := hw i
    unfold weight at h
    exact_mod_cast h
  · intro e
    dsimp [realMu]
    exact_mod_cast hm e

/-- The elementary rotation identity used to expand the completed-square vector. -/
lemma rotated_dot (a b : ℝ) (p q : Point) :
    dot (rotate (angleSquare (0,0) a) p) (rotate (angleSquare (0,0) b) q) =
      dot p q * Real.cos (b-a) - (p.1*q.2-p.2*q.1) * Real.sin (b-a) := by
  rw [Real.cos_sub, Real.sin_sub]
  dsimp [dot, rotate, angleSquare]
  ring

/--
DRAFT_HOLE A2 (finite algebraic identity over real numbers).
Expand z_i as sum_p Rot(theta_p) * vectorTable(c,i,p). The coefficient identity
in `arithmeticValid` identifies the resulting constants, cosine coefficients,
and sine coefficients with c.coeff. Use `rotated_dot`, `normSq_rotate`, rational
cast rules, and finite sums. The sign before the cross product in `rotated_dot`
is negative; the dual subtraction changes it to the positive calculatedB term.
This lemma is an equality, not an assumed certificate lower bound.
-/
lemma certificate_formula {R : ℝ} (N : NormalizedPacking R)
    (c : Certificate) (hc : arithmeticValid c)
    (hm : Matches c (N.k 1) (N.k 2) (N.source 0) (N.source 1) (N.source 2)) :
    dualValue (fun i j => rotate (squares N.centers N.x i) (localVertex j))
      (realLam c) (realMu c) (widths N.x) (normals N.x N.k N.source) =
      polynomial c N.x := by
  have hk : c.k = N.k := by
    funext e
    fin_cases e
    · exact hc.1.trans N.k_zero.symm
    · exact hm.1
    · exact hm.2.1
  have hs : c.source = N.source := by
    funext e
    fin_cases e
    · exact hm.2.2.1
    · exact hm.2.2.2.1
    · exact hm.2.2.2.2
  -- Rewrite normals using hk and hs, expand zVector via vectorTable, and collect terms.
  sorry

end ThreeSquares.Draft
