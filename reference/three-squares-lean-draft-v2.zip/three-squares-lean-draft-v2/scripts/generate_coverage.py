from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
text = (root/'ThreeSquares/Certificates.lean').read_text()
rows=[]
for m in re.finditer(r'-- Pattern \((\d), (\d)\); sources \((\d), (\d), (\d)\); (base|supplement [GHJ])\.\ndef (cert\d+) :', text):
    rows.append((tuple(map(int,m.groups()[:5])),m[6],m[7]))
bases=[r for r in rows if r[1]=='base']
supp={r[0]:r[2] for r in rows if r[1]!='base'}
# This script only emits text. All validity/case claims are Lean propositions.
head='''import ThreeSquares.Certificates
import ThreeSquares.AngleDomain

/-!
Explicit selection of a certificate and a triangle for every branch and every point.
The quadrilateral in the last exceptional branch is split into two triangles.
Text was generated from the existing certificate record names; proof bodies use
Lean's ordinary `decide` and the barycentric proofs in AngleDomain, not Python checks.
UNCOMPILED DRAFT.
-/
noncomputable section
namespace ThreeSquares.Coverage
open RatData AngleDomain

 def cornerPoint : Corner → Point
  | .O => O
  | .V => V
  | .W => W
  | .P => P
  | .Z => Z

def Matches (c : Certificate) (k02 k12 : Fin 4) (s0 s1 s2 : Fin 3) : Prop :=
  c.k 1 = k02 ∧ c.k 2 = k12 ∧
  c.source 0 = s0 ∧ c.source 1 = s1 ∧ c.source 2 = s2

instance (c : Certificate) (k02 k12 : Fin 4) (s0 s1 s2 : Fin 3) :
    Decidable (Matches c k02 k12 s0 s1 s2) := by
  unfold Matches
  infer_instance

def Supports (c : Certificate) (p q r : Corner) : Prop :=
  p ∈ c.corners ∧ q ∈ c.corners ∧ r ∈ c.corners

instance (c : Certificate) (p q r : Corner) : Decidable (Supports c p q r) := by
  unfold Supports
  infer_instance

set_option maxRecDepth 200000
set_option maxHeartbeats 0

lemma admissible_cases : ∀ k02 k12 : Fin 4,
    ∀ s0 s1 s2 : Fin 3,
    (k02, k12) ∈ Combinatorics.remaining →
    (s0, s1, s2) ∈ Combinatorics.sources →
'''
conds=['    ('+' ∧ '.join(f'{v} = {n}' for v,n in zip(['k02','k12','s0','s1','s2'],r[0]))+')' for r in bases]
out=head+' ∨\n'.join(conds)+' := by\n  decide\n\n'
out+='''theorem select {x : Point} (hD : Domain x.1 x.2)
    (k02 k12 : Fin 4) (s0 s1 s2 : Fin 3)
    (hk : (k02, k12) ∈ Combinatorics.remaining)
    (hs : (s0, s1, s2) ∈ Combinatorics.sources) :
    ∃ (c : Certificate) (p q r : Corner),
      arithmeticValid c ∧ Matches c k02 k12 s0 s1 s2 ∧ Supports c p q r ∧
      InTriangle (cornerPoint p) (cornerPoint q) (cornerPoint r) x := by
  rcases admissible_cases k02 k12 s0 s1 s2 hk hs with
    '''+' | '.join(['h']*len(bases))+'\n'
def choose(cert,tri,h,indent):
    p,q,r=tri
    return (' '*indent+f'refine ⟨{cert}, .{p}, .{q}, .{r}, {cert}_checked, by decide, by decide, ?_⟩\n'
            +' '*indent+f'simpa only [cornerPoint, Prod.eta] using {h}\n')
for key,kind,name in bases:
    out+='  · rcases h with ⟨rfl, rfl, rfl, rfl, rfl⟩\n'
    if key not in supp:
        out+=choose(name,('O','V','W'),'(in_full hD)',4)
    elif key == (0,3,1,0,1):
        out+='    rcases cover_G hD with hbase | hextra\n    · '
        block=choose(name,('O','V','Z'),'hbase',6)
        out+=block.lstrip()
        out+='    · '+choose(supp[key],('V','W','Z'),'hextra',6).lstrip()
    elif key == (3,3,1,2,1):
        out+='    rcases cover_J_special hD with hbase | hextra₁ | hextra₂\n'
        for cert,tri,h in [(name,('O','P','Z'),'hbase'),(supp[key],('P','V','W'),'hextra₁'),(supp[key],('P','W','Z'),'hextra₂')]:
            out+='    · '+choose(cert,tri,h,6).lstrip()
    else:
        out+='    rcases cover_H hD with hbase | hextra\n'
        out+='    · '+choose(name,('O','P','W'),'hbase',6).lstrip()
        out+='    · '+choose(supp[key],('P','V','W'),'hextra',6).lstrip()
out+='\nend ThreeSquares.Coverage\n'
(root/'ThreeSquares/Coverage.lean').write_text(out)
print('Wrote Coverage.lean; source-generation only, no verifier or compiler run.')
