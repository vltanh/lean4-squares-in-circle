import ThreeSquares.DraftMain

/-! Not executed in this revision. `optimality_draft` is EXPECTED to depend on sorryAx. -/
#print axioms ThreeSquares.packing_center_bound
#print axioms ThreeSquares.RealChecks.intervals_sound
#print axioms ThreeSquares.Coverage.select
#print axioms ThreeSquares.RealChecks.checked_corner_lower
#print axioms ThreeSquares.RealChecks.concave_triangle_lower
#print axioms ThreeSquares.Draft.normalized_squared_lower
#print axioms ThreeSquares.Draft.optimality_draft
