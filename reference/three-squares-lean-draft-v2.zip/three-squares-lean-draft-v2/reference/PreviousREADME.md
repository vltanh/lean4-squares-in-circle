# Three unit squares in a disk — partial Lean 4 formalization

## Status: partial and uncompiled

This is **not an end-to-end Lean proof** of the unrestricted three-square
packing optimum. The Lean source was written in an environment without a Lean
compiler; it has not been compiled. Elaboration or tactic errors may remain.
The files must be checked with the pinned toolchain before any formal
verification claim is made.

The proposed value is `5 * Real.sqrt 17 / 16`; its square is `425 / 256`.
The informal argument and the earlier Python verifier are not substitutes for
Lean's kernel checking.

## What the source contains

* `Geometry.lean`: arbitrary independently rotated unit squares, disk containment,
  non-overlap of open square interiors, the unrestricted target statement,
  vertex containment, and the radius-squared identity.
* `Construction.lean`: proof scripts for the T arrangement's containment at the
  candidate radius, its pairwise disjoint interiors, and the matching lower
  bound for **that fixed arrangement**, allowing an arbitrary disk center.
* `Dual.lean`: proof scripts for the weighted quadratic certificate inequality,
  starting from genuine vertex-containment and explicit separating inequalities.
* `Arithmetic.lean`: the algebraic center estimate, rational chain contradiction,
  and the positive-semidefinite quadratic-form calculation used in the Hessian test.
* `Combinatorics.lean`: closed finite `decide` proof attempts enumerating all 16
  cardinal patterns and the eight source choices.
* `AngleDomain.lean`: explicit barycentric proof scripts for the full triangle and
  all exceptional region covers. The quadrilateral is triangulated; no area-based
  inference is used.
* `RatDefinitions.lean` and `Certificates.lean`: all 53 rational certificate
  records, recomputation of their coefficients, weight conditions, curvature
  bounds, and 160 rational interval endpoint checks. Every record has a closed
  `by decide` proof attempt. The intervals are data here, not proved enclosures
  of real trigonometric functions.
* `Main.lean`: an explicitly **conditional** final implication, with the remaining
  mathematical obligation named `MissingCertificateExistence`.

There are no deliberately admitted Lean theorems, custom `axiom` declarations,
`sorry` terms, or `native_decide` invocations in the source. This does not imply
completeness or successful compilation. In particular, absence of `sorry` cannot
turn a conditional theorem into an unconditional one.

## The unresolved bridge

`MissingCertificateExistence` has no proof in this project. To establish it,
the following parts of the informal argument still need formal proofs and
integration:

1. Normalize arbitrary square frames by common rigid motions, reflection,
   relabeling, and quarter-turn equivalence to the stated angle triangle.
2. Derive edge-normal separating inequalities from disjoint open interiors,
   prove the actual geometric center estimate, and prove the geometric/trigonometric
   forbidden-chain lemma. The supplied algebraic end steps do not replace these.
3. Identify the real quadratic `dualValue` with the rationally tabulated
   trigonometric polynomial, including rotations and all source choices.
4. Prove the trigonometric bounds, establish real concavity from the Hessian
   calculation, prove the vertex estimates from the rational intervals, and apply
   finite Jensen inequalities on the explicit covers.
5. Use the normalized branch and its region to construct an actual
   `CertificateWitness`, then transport it back to the original packing.

These are substantive obligations. They are **not** inserted into the definition
of `Packing`, and they are **not** postulated as axioms.

## Toolchain and checking

The project targets Lean `4.19.0` and mathlib tag `v4.19.0`.
With Elan/Lake installed and network access for the dependencies:

```sh
cd three-squares-lean
bash scripts/check.sh
```

Equivalently:

```sh
lake update
lake exe cache get
lake build
lake env lean AxiomAudit.lean
```

For a smaller first build, check the construction and dual modules before the
large finite-data module:

```sh
lake build ThreeSquares.Construction ThreeSquares.Dual
```

`AxiomAudit.lean` prints theorem dependencies. Inspect the final theorem's type
as well as its axioms: its `MissingCertificateExistence` argument is an essential
hypothesis, not a theorem proved elsewhere.

## Reproducing the data generation

```sh
python reference/three_squares_circle_certificate.py
python scripts/generate_data.py
```

The first script is the earlier exact-arithmetic Python verifier. The second
regenerates `Certificates.lean` and checks that the coarser rational intervals used
here preserve the `1/250` gap. Generation does not supply Lean proof objects;
Lean must independently check the generated `by decide` proofs.

See `VERIFICATION.md` for what was actually executed in the authoring environment.
