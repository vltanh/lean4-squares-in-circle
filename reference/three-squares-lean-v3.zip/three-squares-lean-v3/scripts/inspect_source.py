#!/usr/bin/env python3
"""Inspect Lean source text without invoking Lean, Lake, or a numerical verifier.

This is not a Lean parser, type checker, proof verifier, or axiom audit.
It masks nested block comments, line comments, and ordinary string literals,
then reports selected textual markers and project-local import dependencies.
"""
from __future__ import annotations
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MARKERS = ('sorry', 'admit', 'axiom', 'sorryAx', 'native_decide',
           'unsafe', 'implemented_by', 'MissingCertificateExistence')

def mask_noncode(text: str) -> str:
    out = list(text)
    i, n, depth = 0, len(text), 0
    while i < n:
        if text.startswith('/-', i):
            depth = 1
            start = i
            i += 2
            while i < n and depth:
                if text.startswith('/-', i):
                    depth += 1; i += 2
                elif text.startswith('-/', i):
                    depth -= 1; i += 2
                else:
                    i += 1
            if depth:
                raise ValueError('Unclosed Lean block comment')
            for j in range(start, i):
                if out[j] != '\n': out[j] = ' '
        elif text.startswith('--', i):
            while i < n and text[i] != '\n':
                out[i] = ' '; i += 1
        elif text[i] == '"':
            start = i
            i += 1
            closed = False
            while i < n:
                if text[i] == '\\': i += 2
                elif text[i] == '"':
                    i += 1; closed = True; break
                else: i += 1
            if not closed: raise ValueError('Unclosed ordinary string literal')
            for j in range(start, min(i, n)):
                if out[j] != '\n': out[j] = ' '
        else:
            i += 1
    return ''.join(out)

paths = sorted(ROOT.rglob('*.lean'))
modules = {'.'.join(p.relative_to(ROOT).with_suffix('').parts): p for p in paths}
records = []
graph = {}
missing = []
totals = {word: 0 for word in MARKERS}
for module, path in modules.items():
    raw = path.read_text(encoding='utf-8')
    code = mask_noncode(raw)
    counts = {word: len(re.findall(r'(?<![\w\'])' + re.escape(word) + r'(?![\w\'])', code))
              for word in MARKERS}
    for word, value in counts.items(): totals[word] += value
    imports = []
    for line in code.splitlines():
        m = re.match(r'^\s*import\s+(.+)$', line)
        if m: imports.extend(m.group(1).split())
    local = [name for name in imports if name == 'ThreeSquares' or name.startswith('ThreeSquares.')]
    for name in local:
        if name not in modules: missing.append({'from': module, 'missing': name})
    graph[module] = local
    records.append({'path': str(path.relative_to(ROOT)), 'module': module,
                    'lines': len(raw.splitlines()),
                    'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                    'imports': imports, 'selected_marker_counts': counts,
                    'theorem_or_lemma_keywords': len(re.findall(r'\b(?:theorem|lemma)\b', code))})

active, finished, cycles = [], set(), []
def visit(module: str) -> None:
    if module in active:
        cycles.append(active[active.index(module):] + [module]); return
    if module in finished or module not in graph: return
    active.append(module)
    for dep in graph[module]: visit(dep)
    active.pop(); finished.add(module)
for module in graph: visit(module)

result = {
    'kind': 'TEXT-ONLY SOURCE INSPECTION; NOT LEAN VERIFICATION',
    'compiler_invoked': False,
    'lake_invoked': False,
    'numerical_verifier_invoked': False,
    'kernel_axiom_audit_performed': False,
    'lean_file_count': len(records),
    'lean_line_count': sum(r['lines'] for r in records),
    'theorem_or_lemma_keyword_count': sum(r['theorem_or_lemma_keywords'] for r in records),
    'selected_marker_counts_excluding_comments_and_strings': totals,
    'missing_project_local_imports': missing,
    'project_local_import_cycles': cycles,
    'limitations': [
        'The masking scanner is not a Lean parser.',
        'Absence of selected markers does not establish that any proof elaborates.',
        'Resolved import filenames do not establish declarations, types, or proof dependencies.',
        'No conclusion about kernel acceptance or mathematical correctness is made.'
    ],
    'files': records,
}
(ROOT/'SOURCE_INSPECTION.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps({key: value for key, value in result.items() if key != 'files'}, indent=2))
