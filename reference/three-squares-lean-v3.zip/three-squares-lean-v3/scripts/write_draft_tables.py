"""Generate Lean source from existing certificate records. This is not a verifier."""
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
s = (root/'ThreeSquares/Certificates.lean').read_text()
records=[]
pat=r'-- Pattern \((\d), (\d)\); sources \((\d), (\d), (\d)\); ([^\n]+)\.\ndef cert(\d{3}) : Certificate where'
for m in re.finditer(pat,s):
    a,b,s0,s1,s2,kind,num=m.groups()
    records.append(dict(pattern=(int(a),int(b)),sources=(int(s0),int(s1),int(s2)),kind=kind,i=int(num)))
if len(records)!=53:
    raise ValueError('Expected exactly 53 certificate declarations in source')
bases=[r for r in records if r['kind']=='base']
if len(bases)!=48:
    raise ValueError('Expected exactly 48 base certificate declarations in source')
lines=['import ThreeSquares.ConcavityDraft','',
'''/-! Explicit branch-to-certificate selection. Uncompiled source draft.
This file is generated as text. All claims about finite data are Lean `decide`
proof scripts. Generation itself provides no logical evidence. -/
namespace ThreeSquares.Draft
open RatData
set_option maxRecDepth 200000
set_option maxHeartbeats 0
''',
'def table : Fin 53 → Certificate :=',
'  !['+', '.join(f'cert{i:03d}' for i in range(53))+']','',
'''theorem table_checked (i : Fin 53) : arithmeticValid (table i) := by
  fin_cases i <;> decide
''',
'def baseIndex : Fin 48 → Fin 53 :=',
'  !['+', '.join(str(r['i']) for r in bases)+']','',
'''def branchK (j : Fin 48) : Fin 3 → Fin 4 := (table (baseIndex j)).k
def branchSource (j : Fin 48) : Fin 3 → Fin 3 := (table (baseIndex j)).source

theorem branch_lookup :
    ∀ k02 k12 : Fin 4, (k02,k12) ∈ Combinatorics.remaining →
    ∀ s0 s1 s2 : Fin 3, (s0,s1,s2) ∈ Combinatorics.sources →
      ∃ j : Fin 48,
        branchK j = ![0,k02,k12] ∧ branchSource j = ![s0,s1,s2] := by
  decide

noncomputable section

def Covers (j : Fin 48) (x : Point) : Prop :=
  ∃ i : Fin 53, (table i).k = branchK j ∧
    (table i).source = branchSource j ∧
    x ∈ convexHull ℝ (cornerPoint '' {p | p ∈ (table i).corners})

theorem branch_cover (j : Fin 48) (x : Point)
    (hx : AngleDomain.Domain x.1 x.2) : Covers j x := by
  fin_cases j
''']
def proof_for_cert(i,p,q,r,h,indent='    '):
    return [indent+f'refine ⟨{i}, by decide, by decide, ?_⟩',
            indent+f'exact triangle_subset_hull (table {i}).corners .{p} .{q} .{r}',
            indent+'  (by decide) (by decide) (by decide) '+h]
for r in bases:
    supp=next((v for v in records if v['kind']!='base' and v['pattern']==r['pattern'] and v['sources']==r['sources']),None)
    if supp is None:
        lines+=['  ·']+proof_for_cert(r['i'],'O','V','W','(AngleDomain.in_full hx)')
        continue
    tag=supp['kind'].split()[-1]
    if tag=='G':
        lines+=['  · rcases AngleDomain.cover_G hx with h | h','    ·']
        lines+=proof_for_cert(r['i'],'O','V','Z','h','      ')
        lines+=['    ·']+proof_for_cert(supp['i'],'V','W','Z','h','      ')
    elif tag=='J' and r['sources']==(1,2,1):
        lines+=['  · rcases AngleDomain.cover_J_special hx with h | h | h','    ·']
        lines+=proof_for_cert(r['i'],'O','P','Z','h','      ')
        lines+=['    ·']+proof_for_cert(supp['i'],'P','V','W','h','      ')
        lines+=['    ·']+proof_for_cert(supp['i'],'P','W','Z','h','      ')
    else:
        lines+=['  · rcases AngleDomain.cover_H hx with h | h','    ·']
        lines+=proof_for_cert(r['i'],'O','P','W','h','      ')
        lines+=['    ·']+proof_for_cert(supp['i'],'P','V','W','h','      ')
lines+=['', '''/-- Every surviving source/cardinal pattern has a real-valued valid certificate. -/
theorem select_certificate (k : Fin 3 → Fin 4) (s : Fin 3 → Fin 3)
    (hk0 : k 0 = 0)
    (hk : (k 1,k 2) ∈ Combinatorics.remaining)
    (hs : ∀ e, s e = first e ∨ s e = last e)
    (x : Point) (hx : AngleDomain.Domain x.1 x.2) :
    ∃ i : Fin 53, (table i).k = k ∧ (table i).source = s ∧
      targetSq ≤ polynomial (table i) x := by
  have hsv : (s 0,s 1,s 2) ∈ Combinatorics.sources := by
    apply (Combinatorics.source_classification (s 0) (s 1) (s 2)).mp
    simpa [first,last] using And.intro (hs 0) (And.intro (hs 1) (hs 2))
  obtain ⟨j,hjk,hjs⟩ := branch_lookup (k 1) (k 2) hk (s 0) (s 1) (s 2) hsv
  obtain ⟨i,hik,his,hix⟩ := branch_cover j x hx
  refine ⟨i, ?_, ?_, certificate_on_hull (table i) (table_checked i) x hix⟩
  · rw [hik,hjk]
    funext e
    fin_cases e <;> simp [hk0]
  · rw [his,hjs]
    funext e
    fin_cases e <;> simp

end ThreeSquares.Draft
''']
(root/'ThreeSquares/BranchCover.lean').write_text('\n'.join(lines))
# Explicit finite normalization makes the algebraic identities independently
# elaboratable one certificate at a time; no Python algebra is trusted.
unfold=', '.join(f'cert{i:03d}' for i in range(53))
(root/'ThreeSquares/CoefficientBridge.lean').write_text('''import ThreeSquares.BranchCover
import ThreeSquares.Dual

/-! DRAFT: real geometry / rational coefficient identity. Not compiled. -/
noncomputable section
open scoped BigOperators
namespace ThreeSquares.Draft
open RatData

def theta (x : Point) : Fin 3 → ℝ := ![0, Real.pi*x.1, Real.pi*x.2]

def rotation (t : ℝ) (p : Point) : Point :=
  (Real.cos t*p.1-Real.sin t*p.2, Real.sin t*p.1+Real.cos t*p.2)

def castPoint (p : RPoint) : Point := (p.1,p.2)

def angularSquares (c : Fin 3 → Point) (x : Point) : Fin 3 → UnitSquare :=
  fun i => {
    center := c i
    cosine := Real.cos (theta x i)
    sine := Real.sin (theta x i)
    unit := by nlinarith [Real.sin_sq_add_cos_sq (theta x i)] }

def vertices (x : Point) (i : Fin 3) (j : Fin 4) : Point :=
  rotation (theta x i) (localVertex j)

def normal (x : Point) (k : Fin 3 → Fin 4) (s : Fin 3 → Fin 3) (e : Fin 3) : Point :=
  rotation (theta x (s e)) (castPoint (dirs (k e)))

def halfWidth (t : ℝ) : ℝ := (1+Real.cos t+Real.sin t)/2

def widths (x : Point) (e : Fin 3) : ℝ := halfWidth (arguments x e)

def lamReal (c : Certificate) (i : Fin 3) (j : Fin 4) : ℝ := c.lam i j

def muReal (c : Certificate) (e : Fin 3) : ℝ := c.mu e

/-- All 53 symbolic identities are real equalities, not checks of a Python output. -/
theorem coefficient_identity (i : Fin 53) (x : Point) :
    dualValue (vertices x) (lamReal (table i)) (muReal (table i))
      (widths x) (normal x (table i).k (table i).source) = polynomial (table i) x := by
  have hA := Real.sin_sq_add_cos_sq (Real.pi*x.1)
  have hB := Real.sin_sq_add_cos_sq (Real.pi*x.2)
  fin_cases i
  all_goals
    norm_num [table, '''+unfold+''', dualValue, zVector, mass, moment,
      force, edgeStart, edgeEnd, vertices, normal, widths, halfWidth,
      lamReal, muReal, theta, arguments, rotation, castPoint, dirs, localVertex,
      normSq, dot, add, sub, scale, polynomial, A, B,
      Fin.sum_univ_succ, Real.sin_sub, Real.cos_sub]
    <;> nlinarith [hA,hB]

/-- Rational admissibility transfers to the real primal-dual inequality. -/
theorem table_dual_bound (i : Fin 53) (x : Point) (c : Fin 3 → Point) (R : ℝ)
    (hp : Packing (angularSquares c x) (0,0) R)
    (hsep : ∀ e, widths x e ≤ dot
      (normal x (table i).k (table i).source e)
      (sub (c (edgeEnd e)) (c (edgeStart e)))) :
    polynomial (table i) x ≤ R^2 := by
  rcases table_checked i with
    ⟨hk0,hs,hlam,hsum,hw,hmu,hcoeff,hcurv0,hcurv1,hcurv2,hcorners⟩
  rw [← coefficient_identity i x]
  apply three_square_dual (R^2) c (vertices x)
    (normal x (table i).k (table i).source)
    (lamReal (table i)) (muReal (table i)) (widths x)
  · intro i j
    exact_mod_cast hlam i j
  · change (∑ j, ∑ k, ((table i).lam j k : ℝ)) = 1
    exact_mod_cast hsum
  · intro j
    change (0:ℝ) < ∑ k, ((table i).lam j k : ℝ)
    have h : (0:ℚ) < ∑ k, (table i).lam j k := hw j
    exact_mod_cast h
  · intro e
    exact_mod_cast hmu e
  · intro j k
    change normSq (rotate (angularSquares c x j) (localVertex k)) = 1/2
    rw [normSq_rotate,localVertex_normSq]
  · intro j k
    simpa [vertices, rotation, angularSquares, sub, add, rotate] using
      packing_vertex_bound hp j k
  · exact hsep

end ThreeSquares.Draft
''')
