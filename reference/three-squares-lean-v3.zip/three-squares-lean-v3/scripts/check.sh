#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v lake >/dev/null 2>&1; then
  printf '%s\n' 'NOT CHECKED: Lake/Lean is not installed or not on PATH.' >&2
  exit 127
fi
lake update
lake exe cache get
lake build
lake env lean AxiomAudit.lean
