import ThreeSquares

-- A future kernel-dependency inspection, NOT executed during preparation.
-- Source scanning cannot predict whether elaboration will succeed or certify
-- which axioms the elaborated declarations will depend on.
#print axioms ThreeSquares.Draft.cosInterval_sound
#print axioms ThreeSquares.Draft.sinInterval_sound
#print axioms ThreeSquares.Draft.polynomial_concave
#print axioms ThreeSquares.Draft.coefficient_identity
#print axioms ThreeSquares.Draft.select_certificate
#print axioms ThreeSquares.Draft.normalize_orientations
#print axioms ThreeSquares.Draft.choose_separating_axes
#print axioms ThreeSquares.Draft.forbidden_chain
#print axioms ThreeSquares.Draft.optimality_draft
#print axioms ThreeSquares.Draft.optimality_and_attainment_draft
