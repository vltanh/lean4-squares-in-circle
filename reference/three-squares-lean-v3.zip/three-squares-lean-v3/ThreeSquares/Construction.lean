import ThreeSquares.Geometry

/-!
# The T construction and its exact enclosing radius

These proofs concern a specific arrangement and its best enclosing disk.
They do NOT assert that every three-square arrangement is no better.
Status: source draft, not compiled in the authoring environment.
-/

noncomputable section
namespace ThreeSquares

def tSquares : Fin 3 → UnitSquare :=
  ![axisSquare (-1) (-1), axisSquare 0 (-1), axisSquare (-1 / 2) 0]

def tCenter : Point := (0, -3 / 16)

lemma square_bound {z t : ℝ} (h0 : -t ≤ z) (h1 : z ≤ t) : z ^ 2 ≤ t ^ 2 := by
  have h := mul_nonneg (show 0 ≤ z + t by linarith) (show 0 ≤ t - z by linarith)
  nlinarith

lemma lower_strip_fits (p : Point)
    (hx0 : -1 ≤ p.1) (hx1 : p.1 ≤ 1)
    (hy0 : -1 ≤ p.2) (hy1 : p.2 ≤ 0) :
    inDisk tCenter candidateRadius p := by
  have hx := square_bound hx0 hx1
  have hy : (p.2 + 3 / 16) ^ 2 ≤ (13 / 16 : ℝ) ^ 2 :=
    square_bound (by linarith) (by linarith)
  unfold inDisk
  rw [candidateRadius_sq]
  dsimp [normSq, sub, tCenter, targetSq]
  nlinarith

lemma upper_square_fits (p : Point)
    (hx0 : -(1 / 2 : ℝ) ≤ p.1) (hx1 : p.1 ≤ 1 / 2)
    (hy0 : 0 ≤ p.2) (hy1 : p.2 ≤ 1) :
    inDisk tCenter candidateRadius p := by
  have hx := square_bound hx0 hx1
  have hy : (p.2 + 3 / 16) ^ 2 ≤ (19 / 16 : ℝ) ^ 2 :=
    square_bound (by linarith) (by linarith)
  unfold inDisk
  rw [candidateRadius_sq]
  dsimp [normSq, sub, tCenter, targetSq]
  nlinarith

lemma tSquares_contained (i : Fin 3) (p : Point)
    (h : closedSquare (tSquares i) p) : inDisk tCenter candidateRadius p := by
  fin_cases i
  · change closedSquare (axisSquare (-1) (-1)) p at h
    rcases (closed_axisSquare_iff _ _ _).mp h with ⟨hx0, hx1, hy0, hy1⟩
    exact lower_strip_fits p hx0 (by linarith) hy0 (by linarith)
  · change closedSquare (axisSquare 0 (-1)) p at h
    rcases (closed_axisSquare_iff _ _ _).mp h with ⟨hx0, hx1, hy0, hy1⟩
    exact lower_strip_fits p (by linarith) (by linarith) hy0 (by linarith)
  · change closedSquare (axisSquare (-1 / 2) 0) p at h
    rcases (closed_axisSquare_iff _ _ _).mp h with ⟨hx0, hx1, hy0, hy1⟩
    exact upper_square_fits p hx0 (by linarith) hy0 (by linarith)

lemma axis_disjoint_horizontal {x y x' y' : ℝ} (h : x + 1 ≤ x') (p : Point) :
    ¬ (openSquare (axisSquare x y) p ∧ openSquare (axisSquare x' y') p) := by
  rintro ⟨h0, h1⟩
  rcases (open_axisSquare_iff _ _ _).mp h0 with ⟨_, hx, _, _⟩
  rcases (open_axisSquare_iff _ _ _).mp h1 with ⟨hx', _, _, _⟩
  linarith

lemma axis_disjoint_vertical {x y x' y' : ℝ} (h : y + 1 ≤ y') (p : Point) :
    ¬ (openSquare (axisSquare x y) p ∧ openSquare (axisSquare x' y') p) := by
  rintro ⟨h0, h1⟩
  rcases (open_axisSquare_iff _ _ _).mp h0 with ⟨_, _, _, hy⟩
  rcases (open_axisSquare_iff _ _ _).mp h1 with ⟨_, _, hy', _⟩
  linarith

lemma tSquares_disjoint (i j : Fin 3) (hij : i ≠ j) (p : Point) :
    ¬ (openSquare (tSquares i) p ∧ openSquare (tSquares j) p) := by
  fin_cases i <;> fin_cases j
  · exact (hij rfl).elim
  · exact axis_disjoint_horizontal (by norm_num) p
  · exact axis_disjoint_vertical (by norm_num) p
  · intro h
    exact axis_disjoint_horizontal (by norm_num) p ⟨h.2, h.1⟩
  · exact (hij rfl).elim
  · exact axis_disjoint_vertical (by norm_num) p
  · intro h
    exact axis_disjoint_vertical (by norm_num) p ⟨h.2, h.1⟩
  · intro h
    exact axis_disjoint_vertical (by norm_num) p ⟨h.2, h.1⟩
  · exact (hij rfl).elim

/-- An unconditional construction at the proposed optimal radius. -/
theorem tSquares_packing : Packing tSquares tCenter candidateRadius := by
  exact ⟨candidateRadius_nonneg, tSquares_contained, tSquares_disjoint⟩

theorem exists_packing_at_candidate :
    ∃ (S : Fin 3 → UnitSquare) (o : Point), Packing S o candidateRadius := by
  exact ⟨tSquares, tCenter, tSquares_packing⟩

/-- Four corners already force the claimed radius for the fixed T arrangement. -/
lemma four_corners_lower {o : Point} {R : ℝ}
    (h0 : inDisk o R (-1, -1)) (h1 : inDisk o R (1, -1))
    (h2 : inDisk o R (-1 / 2, 1)) (h3 : inDisk o R (1 / 2, 1)) :
    targetSq ≤ R ^ 2 := by
  unfold inDisk normSq sub at h0 h1 h2 h3
  dsimp at h0 h1 h2 h3
  unfold targetSq
  -- Weighted sum: 19/64, 19/64, 13/64, 13/64.
  -- Its value is 425/256 + o.x² + (o.y + 3/16)².
  nlinarith [sq_nonneg o.1, sq_nonneg (o.2 + 3 / 16)]

/-- Exact minimum over disk centers for THIS arrangement only. -/
theorem tSquares_radius_lower {o : Point} {R : ℝ}
    (hp : Packing tSquares o R) : candidateRadius ≤ R := by
  apply radius_lower_of_squared hp.1
  apply four_corners_lower
  · apply hp.2.1 0
    change closedSquare (axisSquare (-1) (-1)) (-1, -1)
    rw [closed_axisSquare_iff]
    norm_num
  · apply hp.2.1 1
    change closedSquare (axisSquare 0 (-1)) (1, -1)
    rw [closed_axisSquare_iff]
    norm_num
  · apply hp.2.1 2
    change closedSquare (axisSquare (-1 / 2) 0) (-1 / 2, 1)
    rw [closed_axisSquare_iff]
    norm_num
  · apply hp.2.1 2
    change closedSquare (axisSquare (-1 / 2) 0) (1 / 2, 1)
    rw [closed_axisSquare_iff]
    norm_num

end ThreeSquares
