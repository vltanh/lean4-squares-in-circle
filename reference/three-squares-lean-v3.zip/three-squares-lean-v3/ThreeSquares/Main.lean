import ThreeSquares.GeometricReduction
import ThreeSquares.Construction

/-!
End-to-end assembly of the proposed proof, revision 3.

Every project lemma used below has a proposed proof body. In particular, the
geometric reductions are no longer admitted or supplied as theorem hypotheses.
This source has NOT been compiled or kernel-checked. The proof scripts and their
library interfaces remain subject to verification and correction.
-/
noncomputable section
namespace ThreeSquares.Draft
open RatData

theorem optimality_draft : OptimalityStatement := by
  intro S o R hp
  apply radius_lower_of_squared hp.1
  by_contra hnot
  have hsmall : R^2 < targetSq := lt_of_not_ge hnot
  obtain ⟨c,x,hx,hp0⟩ := normalize_orientations S o R hp
  obtain ⟨c',k,s,hp1,hk0,hs,hsep⟩ := choose_separating_axes c x R hx hp0
  have hchain := forbidden_chain c' x R hx hp1 hsmall k s hk0 hs hsep
  have hk : (k 1,k 2) ∈ Combinatorics.remaining :=
    (Combinatorics.classification (k 1) (k 2)).mp hchain
  obtain ⟨i,hik,his,hvalue⟩ := select_certificate k s hk0 hk hs x hx
  have hdual : polynomial (table i) x ≤ R^2 := by
    apply table_dual_bound i x c' R hp1
    simpa only [hik,his] using hsep
  exact (not_le_of_gt hsmall) (hvalue.trans hdual)

/-- Proposed global bound together with the explicit attaining construction. -/
theorem optimality_and_attainment_draft :
    OptimalityStatement ∧
      ∃ (S : Fin 3 → UnitSquare) (o : Point), Packing S o candidateRadius := by
  exact ⟨optimality_draft, exists_packing_at_candidate⟩

end ThreeSquares.Draft
