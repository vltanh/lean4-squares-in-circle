import ThreeSquares.ForbiddenChain

/-!
The geometric reductions are now supplied by PlaneTools, OrientationNormalization,
SeparatingAxes, AxisSelection, and ForbiddenChain. All are uncompiled proof drafts.
-/
