# Three independently rotated unit squares in a disk — revision 3

## Status

**Uncompiled, end-to-end Lean proof draft. Not a kernel-verified result.**

Every previously admitted lemma in the selected revision-2 project now has an
explicit proposed proof body. The final theorem has only the original packing
hypothesis; it does not take normalization, separating axes, certificate existence,
or the desired bound as additional assumptions.

No Lean, Lake, compiler installation, numerical verifier, or verification service
was run in preparing this revision. The source-only inspection reports textual
properties and local import consistency; it does not establish elaboration,
tactic success, soundness of library applications, or mathematical correctness.
Proof scripts may require substantial correction when they are checked.

The project configuration targets Lean 4.19.0 and mathlib v4.19.0. These are the
inherited version pins, not a claim that the new source is compatible with them.

## The statement

The definition `ThreeSquares.Packing` in `ThreeSquares/Geometry.lean` consists of:

- a nonnegative disk radius;
- containment of each closed unit square in the disk;
- pairwise disjoint open square interiors.

Each square has its own arbitrary orthonormal coordinate frame. The definition
contains no separating-axis condition, orientation restriction, or certificate
assumption. Its geometric fields and the target radius are unchanged.

The final proposed declarations in `ThreeSquares/Main.lean` are:

```lean
theorem optimality_draft : OptimalityStatement := by
  -- explicit proof body in Main.lean

theorem optimality_and_attainment_draft :
    OptimalityStatement ∧
      ∃ (S : Fin 3 → UnitSquare) (o : Point),
        Packing S o candidateRadius := by
  exact ⟨optimality_draft, exists_packing_at_candidate⟩
```

Here `candidateRadius = 5 * Real.sqrt 17 / 16` and
`targetSq = 425 / 256`. The commented abbreviation above is only a README excerpt;
the Lean file contains the full theorem body.

## The formerly admitted geometry

### 1. Orientation normalization

`PlaneTools.lean` gives coordinate proofs for rotating, reflecting, translating,
reindexing, and quarter-turn reframing of squares. A frame is first moved to the
first quadrant by zero, one, two, or three quarter turns, and represented by
`Real.arccos`. This avoids any assumed angle-modulus normal form.

`OrientationNormalization.lean` explicitly sorts three angles, considers all
three possible largest cyclic gaps, and reflects the smaller remaining gap to
the first position. Its `normalize_orientations` body constructs the normalized
packing with angle coordinates `(a/pi, b/pi)` in the triangle
`0 <= a`, `2*a <= b`, `2*b-a <= pi/2`. Boundary angles and ties are included.

### 2. Separating axes

`SeparatingAxes.lean` starts from separation of disjoint open convex sets, using
mathlib's `geometric_hahn_banach_open_open`. Explicit shrinking support vertices
turn the functional separation into a non-strict support-radius inequality.
An algebraic support calculation in the two sectors of the first quadrant,
transported through four quarter turns, derives the four unsigned edge axes.
It does not assume a separating-axis theorem specialized to polygons.

`AxisSelection.lean` transports these axes back to each square pair, selects
the direction sign and endpoint source, and normalizes the first cardinal
index. Its `choose_separating_axes` now has an explicit proof body.

### 3. The forbidden chain

`ForbiddenChain.lean` connects vertex containment to the center bound, derives
a chord lower bound for the support width, and gives a coordinate
Cauchy–Schwarz inequality. It bounds the chord of two equally indexed normals
by their angle difference and handles all directed-edge cases.

The two chain inequalities give the incompatible bounds

```text
2 + (7/44)*phi <= L <= 11/8 + (11/16)*phi,
phi <= 22/21.
```

The module finishes with the explicit body of `forbidden_chain`.
Euclidean estimates use `normSq p = p.1^2 + p.2^2`; they do not use the product
type's default norm as a substitute for Euclidean length.

## Certificate verification and the former Python checks

No Python code is imported, executed, or trusted by a Lean proof term in this
project. The source expresses the necessary obligations in Lean:

| Obligation | Source |
|---|---|
| Cardinal and source enumeration | `Combinatorics.lean` |
| Rational certificate weights, curvature margins, endpoint comparisons | `RatDefinitions.lean`, `Certificates.lean` |
| Real meaning of all required trigonometric enclosures | `RealBounds.lean` |
| Transfer of rational bounds to real values and Hessian inequalities | `RealPolynomial.lean` |
| Whole-domain concavity and convex-hull propagation | `ConcavityDraft.lean` |
| All 48 branches and their subdivisions, using 53 certificates | `AngleDomain.lean`, `BranchCover.lean` |
| Weighted dual inequality and the real coefficient identities | `Dual.lean`, `CoefficientBridge.lean` |
| Construction attaining the candidate radius | `Construction.lean` |

The Python Taylor-series algorithm is **replaced**, not ported instruction for
instruction. The six endpoint angles are `0`, `pi/12`, `pi/8`, `pi/6`, `pi/4`,
and `pi/3`. Exact radical identities and rational square-root bounds provide the
needed real enclosures. This removes the need for a separate Machin-formula or
alternating-series computation in the Lean dependency chain.

Closed rational obligations use ordinary `decide` proof scripts, not a Python
oracle or `native_decide`. Their presence is not a claim that these scripts
have already been accepted by Lean.

## Files for iteration

`ThreeSquares.lean` imports `ThreeSquares.Main`. `AxiomAudit.lean` contains
unexecuted dependency-inspection commands. `VERIFICATION.md` and
`SOURCE_INSPECTION.json` state exactly which text-only checks were performed.
The source-inspection script is `scripts/inspect_source.py`.

The pre-existing `scripts/check.sh` is included solely for a later local check;
it was not run. Source generators and the old Python reference are retained
for provenance only and are not proof dependencies. Historical conditional
proof material is confined to `reference/LegacyMain.lean.txt` and is not imported.

This revision removes deliberate mathematical admissions from the source.
It does not replace the need to check every proof body and its dependencies.
