import ThreeSquares.Main
