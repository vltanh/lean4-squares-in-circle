# Proof map — proposed Lean dependency chain

This is a guide to uncompiled source, not a verification report.

## Unrestricted lower bound

The final declaration is `ThreeSquares.Draft.optimality_draft`.

1. `normalize_orientations` replaces an arbitrary packing with a rigidly
   equivalent, relabeled angular packing in the two-dimensional angle triangle.
2. `choose_separating_axes` derives signed edge-normal inequalities for the
   three pairs. It arranges that the first cardinal index is zero.
3. If the radius is below the candidate, `forbidden_chain` excludes the ten
   cardinal patterns containing a directed chain with a common index.
4. `Combinatorics.classification` places the remaining cardinal pattern in its
   explicit six-element list. Together with the endpoint choices there are
   48 branches.
5. `select_certificate` chooses one of the 53 concrete rational certificates
   whose designated polygon contains the angle pair. It supplies the real
   inequality `targetSq <= polynomial (table i) x`.
6. `table_dual_bound` uses the actual vertex-containment and separating
   inequalities to give `polynomial (table i) x <= R^2`.
7. The bounds contradict `R^2 < targetSq`. `radius_lower_of_squared` converts
   the squared inequality to the radius inequality.

## The real certificate lower bound

`table_checked` gives the finite rational obligations for each record.
`cosInterval_sound` and `sinInterval_sound` connect stored endpoint intervals to
real trigonometric values. `valueLower_sound` and `checked_corner_lower` transfer
the checked rational comparisons to the real values at designated corners.

`trig_ranges`, `curvatureLower_sound`, and `curvature_form_nonneg` establish
the whole-domain Hessian estimate. `polynomial_concave` applies it to second
derivatives along every segment. `certificate_on_hull` extends the corner
lower bounds to each certificate's polygon. `branch_cover` and
`select_certificate` connect these polygons to all possible branch choices.

## The geometric certificate upper bound

`three_square_dual` in `Dual.lean` completes the square after summing the
weighted primal inequalities. `coefficient_identity` is a real symbolic
identity for each of the 53 records, not an assertion imported from the
Python output. `table_dual_bound` composes the two.

## Attainment

`exists_packing_at_candidate` supplies the T-shaped construction. The final
`optimality_and_attainment_draft` combines this with the proposed global bound.

## Sensitive interfaces to check during iteration

The source includes explicit attempts at the Hahn–Banach functional-to-coordinate
bridge, trigonometric derivative conversions, finite vector indexing,
quarter-turn frame equivalence, real/rational casts, and polynomial identities.
None of these attempts has been elaborated. An error can be substantive as well
as syntactic or related to a tactic or library interface.
